#include<stdio.h>
#include<stdlib.h>

#include "b24ee1021_b24ee1062_b24mt1036_b24ch1025_b24me1071_header.h"

void game();//stating to include

// main fun
int main()
{
    game();
    return 0;
    
}



