#include<stdio.h>
#include<stdlib.h>

#include "b24ee1021_b24ee1062_b24mt1036_b24ch1025_b24me1071_header.h"

void Page2();// stating it

void game()// cannot use main()
{
    Page1();

    system("clear||cls");
    
    Page2();

}
